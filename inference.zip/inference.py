import joblib
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler


NAMElast_encoder = joblib.load(open('NAMElast_encoder.pkl', 'rb'))
NAMEfirst_encoder = joblib.load(open('NAMEfirst_encoder.pkl', 'rb'))
TEAM_encoder = joblib.load(open('TEAM_encoder.pkl', 'rb'))
League_encoder = joblib.load(open('League_encoder.pkl', 'rb'))
scaler = joblib.load(open('scaler.pkl','rb'))
model = joblib.load('model.h5')

def predict(df): 
 
    df = df[['YEAR', 'NAMElast', 'NAMEfirst', 'TEAM', 'League', 'League code',
       'Games', 'At-bats', 'Hits', 'Home runs', 'Runs batted in',
       'Total bases', 'On base', 'Plate appearances', 'Doubles', 'Triples',
       'Stolen bases', 'Caught stealing', 'Bases on balls', 'Struck out',
       'Intentional bases on balls', 'Hit by pitch', 'Sacrifices',
       'Sacrifice flies', 'Grounded into double play', 'Batting average',
       'On base percentage', 'Slugging average', 'Years of experience',
       'Plate appearances per year', 'Major league batting average',
       'Major league on base percentage', 'Major league slugging average',
       'AVGcum', 'OBPcum', 'SLGcum', 'ABcum', 'Rcum', 'Hcum', 'HRcum',
       'RBIcum', 'PAcum', 'OBcum', 'TBcum', 'G_Lag1', 'AB_Lag1', 'R_Lag1',
       'H_Lag1', 'HR_Lag1', 'RBI_Lag1', 'TB_Lag1', 'OB_Lag1', 'PA_Lag1',
       'DBL_Lag1', 'TR_Lag1', 'SB_Lag1', 'CS_Lag1', 'BB_Lag1', 'SO_Lag1',
       'IBB_Lag1', 'HBP_Lag1', 'SH_Lag1', 'SF_Lag1', 'GIDP_Lag1', 'AVG_Lag1',
       'OBP_Lag1', 'SLG_Lag1', 'EXP_Lag1', 'AVGcum_Lag1', 'OBPcum_Lag1',
       'SLGcum_Lag1', 'ABcum_Lag1', 'Rcum_Lag1', 'Hcum_Lag1', 'HRcum_Lag1',
       'RBIcum_Lag1', 'PAcum_Lag1', 'OBcum_Lag1', 'TBcum_Lag1']]
    df.dropna(inplace = True)
    df['NAMElast'] = NAMElast_encoder.transform(df['NAMElast'])
    df['NAMEfirst'] = NAMEfirst_encoder.transform(df['NAMEfirst'])
    df['TEAM'] = TEAM_encoder.transform(df['TEAM'])
    df['League'] = League_encoder.transform(df['League'])
    df_scaled = pd.DataFrame(scaler.transform(df), columns = df.columns)
    predictions = model.predict(df_scaled)
    output = predictions.astype(int)
    output = output.tolist()         
    return output